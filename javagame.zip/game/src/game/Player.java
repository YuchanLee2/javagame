package game;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Player extends JLabel{
	
	private int x;
	private int y;
	
	private ImageIcon playerR;//playerL,playerUp,playerDown;
	public Player() {
		initobject();
		initsetting();
	}
	
	private void initobject()
	{
		playerR = new ImageIcon("image/character/1.png");
		//playerL = new ImageIcon("image/character/1.png");
		//playerUp = new ImageIcon("image/character/1.png");
		//playerDown = new ImageIcon("image/character/1.png");
	}
	private void initsetting()
	{
		x = 700;
		y = 290;
		this.setIcon(playerR);
		setSize(50,50);
		setLocation(x,y);
	}
}
