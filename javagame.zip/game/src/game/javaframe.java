package game;



//import java.awt.event.KeyAdapter;
//import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



public class javaframe extends JFrame {
	
	//private JLabel loadingmap;
	private JLabel gamemap1;
	private Player player;
	
	public javaframe()
	{
		initobject();
		initsetting();
		setVisible(true);
		
	}
	
	
	private void initobject()
	{
		getContentPane().setLayout(null);
		gamemap1 = new JLabel(new ImageIcon("image/map/진짜배경.jpg"));
		setContentPane(gamemap1);
		
		player = new Player();
		player.setLabelFor(gamemap1);
		getContentPane().add(player);
		
		
		//loadingmap = new JLabel(new ImageIcon("image/map/게임_시작_화면.png"));
		//addKeyListener(new KeyListner());
		
	}
	private void initsetting()
	{
		setTitle("굴착소년 쿵");
		setSize(1400,1050);
		setLayout(null);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
	}
	//class KeyListner extends KeyAdapter
	{
		//public void keyPressed(KeyEvent e)
		{
		//	switch(e.getKeyCode())
			{
		//	case KeyEvent.VK_ENTER:

				
			}
		}
	}
	
	public static void main(String[] args)
	{
		new javaframe();
	}
}
